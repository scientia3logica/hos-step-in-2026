# HOS Step-In 2026

학교 수도꼭지 절수·물 튐 방지 학생 프로젝트. 답변과 UI는 한국어로 작성합니다.

## Commands
- Node.js 22 이상. 런타임 의존성 설치 없이 `npm run dev`로 로컬 개발.
- `npm test` / `npm run build` / `node scripts/validate-artifact.mjs`.

## Source of truth
- `public/index.html`: 화면 구조와 문구
- `public/styles.css`: 공통 스타일과 반응형 레이아웃
- `public/community.js`: 소통창·제안·결과 자료실
- `public/app.js`: 절수 계산·개인 실험 기록
- `src/api.mjs`: 공용 게시글·파일·삭제 API
- `src/local-bucket.mjs`: 로컬 개발용 저장소, 운영에는 사용하지 않음
- `scripts/build.mjs`: 위 소스를 단일 Cloudflare Worker로 묶음
- `worker/index.js`, `dist/`: 생성물. 직접 수정 금지.

## Preserve behavior
로그인 없는 공개 참여, 기존 디자인, 게시판 종류(chat/proposal/result), 업로드 최대 20MB/1개, 5초 갱신, 기존 R2 키(posts/, files/, lookup/)와 JSON 필드를 유지합니다. 삭제 키를 API 목록에 노출하지 않습니다. 게시글은 textContent로 렌더링합니다. 기존 localStorage 키를 유지합니다.
운영 게시글·파일을 테스트로 수정하지 마세요. 로컬 데이터는 `.local-data/`에 보관하며 Git에 포함하지 않습니다.

## Deployment
현재 `.chatgpt.site` 운영 주소는 Sites가 관리합니다. 이 프로젝트를 수정하거나 GitHub에 push하는 것만으로 현재 사이트가 자동 갱신되지는 않습니다. Sites에서 새 버전을 배포하거나, README의 개인 Cloudflare 계정 배포 절차를 사용합니다. 새 계정의 R2에는 기존 운영 데이터가 자동 복사되지 않습니다. `.openai/hosting.json`의 기존 project_id/r2는 현재 사이트를 계속 배포할 때 유지합니다.

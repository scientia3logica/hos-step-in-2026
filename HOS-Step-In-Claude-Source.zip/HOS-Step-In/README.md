# HOS Step-In 2026 — 편집 가능한 전체 프로젝트

학교 수도꼭지 물 절약·옷 젖음 방지 프로젝트 사이트입니다. HTML/CSS/JavaScript 화면과 게시글·파일 업로드 서버를 모두 포함합니다. 기존 디자인과 기능을 유지하며 특정 AI 편집기에 종속되지 않습니다.

## Claude Code에서 수정

1. ZIP을 풀고 프로젝트 폴더를 Claude Code 또는 VS Code로 엽니다.
2. Node.js 22 이상을 준비합니다.
3. 프로젝트 폴더 터미널에서 실행합니다.

```sh
npm run dev
```

`http://localhost:8787`에서 확인합니다. 별도 npm 패키지 설치 없이 실행됩니다. 소통창과 파일 업로드도 로컬에서 테스트할 수 있습니다. 테스트 데이터는 `.local-data/`에 저장되며 운영 사이트 데이터와 분리됩니다. 소스 수정 후 브라우저를 새로고침하면 반영됩니다. 서버 코드 수정 시 개발 서버를 재시작합니다.

Claude Code에는 다음처럼 요청하세요.

> CLAUDE.md와 README.md를 읽고 기존 디자인과 기능을 유지하면서 원하는 부분을 수정해 줘. npm test와 npm run build로 검증해 줘.

## 수정할 파일

| 파일 | 역할 |
|---|---|
| public/index.html | 화면 구조·문구 |
| public/styles.css | 색상·크기·배치·모바일 디자인 |
| public/community.js | 소통·제안·결과 업로드 화면 |
| public/app.js | 절수량 계산·개인 실험 기록 |
| src/api.mjs | 공용 게시글과 첨부파일 서버 |
| src/local-bucket.mjs | 로컬 저장소 |
| scripts/build.mjs | 운영 배포 파일 생성 |

`worker/index.js`와 `dist/`는 생성 파일이므로 직접 수정하지 않습니다. `npm run build`가 다시 생성합니다.

## 확인

```sh
npm test
npm run build
node scripts/validate-artifact.mjs
```

## GitHub에 올리기

GitHub에서 빈 저장소를 만든 후, ZIP을 푼 프로젝트 폴더에서 아래 명령을 실행합니다. `<저장소주소>`는 본인 저장소의 HTTPS 주소로 교체합니다.

```sh
git init
git add .
git commit -m "Import HOS Step-In project"
git branch -M main
git remote add origin <저장소주소>
git push -u origin main
```

저장소에서 `.github/workflows/check.yml`이 빌드와 테스트를 자동 수행합니다. 이 작업은 검증만 하며 자동 배포하지 않습니다. Claude Code에서 이 저장소를 clone해 계속 편집할 수 있습니다.

## 현재 사이트에 반영

현재 운영 주소: https://hosstepin2026.scientia3logica.chatgpt.site/

현재 주소는 ChatGPT Sites가 관리합니다. 로컬 수정이나 GitHub push만으로 이 주소가 갱신되지는 않습니다. 수정 프로젝트를 Sites에서 빌드·배포하면 기존 주소와 운영 저장소를 유지할 수 있습니다. `.openai/hosting.json`에 이 사이트의 식별자와 BUCKET 바인딩이 있습니다. 인증 토큰은 포함하지 않았습니다.

## Claude에서 독립적으로 배포하기 — 개인 Cloudflare 계정

Cloudflare 계정과 R2 사용 설정이 필요합니다. 계정 정책과 사용량에 따라 비용이 생길 수 있습니다. `wrangler.jsonc`는 독립 배포용입니다.

```sh
npx wrangler@4 login
npx wrangler@4 r2 bucket create hos-step-in-2026-files
npm run build
npx wrangler@4 deploy
```

배포 명령이 반환하는 새 workers.dev 주소로 접속합니다. 필요하면 wrangler.jsonc의 Worker 이름과 버킷 이름을 본인 계정에 맞게 바꿉니다. 버킷을 이미 생성했다면 생성 명령은 생략합니다.

새 Cloudflare 계정에는 기존 게시글·첨부파일이 자동 이전되지 않습니다. 기존 데이터 이전은 별도 작업이며, 현재 .chatgpt.site 주소를 개인 Cloudflare Worker로 직접 넘기는 설정은 포함하지 않습니다. GitHub Pages만으로는 서버의 공용 게시판·파일 업로드가 작동하지 않습니다.

공식 참고: https://developers.cloudflare.com/workers/wrangler/configuration/ 및 https://developers.cloudflare.com/r2/api/workers/workers-api-usage/

## 포함되지 않은 것

운영 게시글과 업로드 파일, 로그인 세션, 개인 계정 인증정보는 소스 ZIP에 포함하지 않습니다. 삭제 권한은 기존과 같이 글을 작성한 브라우저의 localStorage에 보관됩니다.
